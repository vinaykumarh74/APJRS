<?php
// Secure resume download for job seekers

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';

session_start();

// Require authentication
requireLogin();
$user_id = $_SESSION['user_id'] ?? null;
$user_type = getUserType();

if ($user_type !== 'job_seeker') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Only job seekers can download resumes.']);
    exit;
}

// Fetch resume filename from profile
$profile = $db->fetch("SELECT resume_file FROM job_seekers WHERE user_id = ?", [$user_id]);
if (!$profile || empty($profile['resume_file'])) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'No resume found for your profile.']);
    exit;
}

$resumeFile = $profile['resume_file'];
$resumePath = __DIR__ . '/../../uploads/resumes/' . $resumeFile;

if (!file_exists($resumePath)) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Resume file not found on the server.']);
    exit;
}

// Detect MIME type if possible
$mime = function_exists('mime_content_type') ? mime_content_type($resumePath) : 'application/octet-stream';

header('Content-Description: File Transfer');
header('Content-Type: ' . $mime);
header('Content-Disposition: attachment; filename="' . basename($resumePath) . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($resumePath));
readfile($resumePath);
exit;
?>
